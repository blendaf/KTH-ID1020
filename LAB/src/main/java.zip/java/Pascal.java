
public interface Pascal {

    public void printPascal(int n);
    public int binom(int n, int k);

}
